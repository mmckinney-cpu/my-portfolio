# Monjhara McKinney — Personal Portfolio

## Pages and assets
- `index.html` — Home page and featured IT project concepts
- `projects.html` — Three sample information technology projects
- `about.html` — Biography, skills, and contact details
- `images/portfolio-wireframe.png` — Visual site plan for all three pages

## Design plan
- **Color palette:** navy `#0D47A1`, blue `#42A5F5`, pale blue `#E3F2FD`, charcoal `#263238`
- **Headings:** Poppins, sans-serif
- **Body text:** Inter, sans-serif

This assignment intentionally uses semantic HTML without CSS. The projects are illustrative concepts, not claims of completed professional work.

## Contact
Monjhara McKinney — monjharam@yahoo.com

## GitHub
Create a repository, upload all files including the `images` folder, and submit the repository URL.
